class Pais < ActiveRecord::Base
has_many :departamentos
attr_accessible :nombre 

validates :nombre, :presence => true,
:length => { :maximum => 80 }

end
