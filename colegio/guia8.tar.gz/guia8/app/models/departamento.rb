class Departamento < ActiveRecord::Base

validates :nombre, :presence => true,
:length => { :maximum => 80 }

validates :pais_nombre, :presence => true,
:length => { :maximum => 80 }

  belongs_to :pais
  has_many :municipios
  attr_accessible :nombre, :pais_nombre 

  def pais_nombre
	pais.nombre if pais
	end
	def pais_nombre=(nombre)
	self.pais = Pais.find_or_create_by_nombre(nombre) unless nombre.blank?
	end

end
