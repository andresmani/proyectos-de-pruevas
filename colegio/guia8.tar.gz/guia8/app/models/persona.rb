class Persona < ActiveRecord::Base
  belongs_to :municipio
  attr_accessible :email, :fch_ncto, :identificacion, :nombre, :telefono,  :municipio_nombre

	validates :nombre, :presence => true,
	:length => { :maximum => 80 }

	validates :email, :presence => true,
	:uniqueness => true,
	:format => { :with => /\A[\w+\-.]+@[a-z\d\-.]+\.[a-z]+\z/i }

	validates :identificacion, :presence => true,
	:length => { :minimum => 8 },
	

	validates :telefono, :presence => true,
	:length => { :minimum => 6, :maximum => 15 },
	:numericality => true

	validates :municipio_nombre, :presence => true,
	:length => { :maximum => 80 }


def municipio_nombre
	municipio.nombre if municipio
	end
	def municipio_nombre=(nombre)
	self.municipio = Municipio.find_or_create_by_nombre(nombre) unless nombre.blank?
	end


end
