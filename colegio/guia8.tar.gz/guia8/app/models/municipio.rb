class Municipio < ActiveRecord::Base
  belongs_to :departamento
  has_many  :personas
  attr_accessible :nombre, :departamento_nombre

  validates :nombre, :presence => true,
:length => { :maximum => 80 }

validates :departamento_nombre, :presence => true,
:length => { :maximum => 80 }

    def departamento_nombre
	    departamento.nombre if departamento
	end
	
	def departamento_nombre=(nombre)
	    self.departamento = Departamento.find_or_create_by_nombre(nombre) unless nombre.blank?
	end

	def self.municipio_ubicacion(munic) # este parametro  almacena la informacion del formulario municipio
		@ubicacion = munic.nombre + ' | ' + munic.departamento.nombre + ' | ' + munic.departamento.pais.nombre # la variable @ubicacion me guarda la concatenacion de las tablas

	end
end
