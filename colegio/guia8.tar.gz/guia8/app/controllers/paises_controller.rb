class PaisesController < ApplicationController

  def index
    @paises = Pais.all
    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @paises }
    end
  end

  def show
      @pais = Pais.find(params[:id])
  end

  def new
      @pais = Pais.new
  end

  def edit
      @pais = Pais.find(params[:id])
  end

  def create
      @pais = Pais.new(params[:pais])
      render :action => :new unless @pais.save
  end

  def update
      @pais = Pais.find(params[:id])
      render :action => :edit unless @pais.update_attributes(params[:pais])
  end

  def destroy
      @pais = Pais.find(params[:id])
      @pais.destroy
  end
  
end