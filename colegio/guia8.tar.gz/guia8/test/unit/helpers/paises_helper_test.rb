require 'test_helper'

class PaisesHelperTest < ActionView::TestCase
end
