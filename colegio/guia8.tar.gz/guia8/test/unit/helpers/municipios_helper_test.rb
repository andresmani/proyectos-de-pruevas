require 'test_helper'

class MunicipiosHelperTest < ActionView::TestCase
end
