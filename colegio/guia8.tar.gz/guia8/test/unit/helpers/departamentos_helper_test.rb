require 'test_helper'

class DepartamentosHelperTest < ActionView::TestCase
end
