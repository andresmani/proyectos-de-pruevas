require 'test_helper'

class PaisTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
