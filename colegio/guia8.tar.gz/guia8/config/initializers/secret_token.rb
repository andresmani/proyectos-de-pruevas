# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Guia8::Application.config.secret_token = 'f4ce8f317879e92e4e9647a3de26c0756077ac2110eb7d19d9ccda923467a0db569a2bcf59643382b289f0969e230c91631c3832ab57aedbad1a7cf3c4fd6bcd'
